#include <stdio.h>

int main() {
    int n;
    double sum = 0;
    double average;

    // Input value for n
    printf("Enter the value of n: ");
    scanf("%d", &n);

    // Calculate the sum of numbers from 1 to n
    int i = 1;
    for (;i <= n; i++) {
        sum += i;
    }

    // Calculate the average
    average = sum / n;

    // Print the average
    printf("Average of numbers from 1 to %d is: %.2f\n", n, average);

    return 0;
}

