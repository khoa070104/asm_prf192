#include <stdio.h>

// Function to calculate the expression value S(n)
int calculateExpression(int n) {
    int sum = 0,i = 1;
    for (; i <= n; i++) {
        sum += i * i;
    }
    return sum;
}

int main() {
    int n;
    int result;

    // Input value for n
    printf("Enter the value of n: ");
    scanf("%d", &n);

    // Calculate the expression value
    result = calculateExpression(n);

    // Print the result
    printf("Result: %d\n", result);

    return 0;
}

