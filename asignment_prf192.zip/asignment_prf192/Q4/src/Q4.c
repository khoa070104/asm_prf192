#include <stdio.h>

// Function to calculate gcd of two numbers
int gcd(int a, int b) {
    if (b == 0)
        return a;
    return gcd(b, a % b);
}

// Function to calculate lcm of two numbers
int lcm(int a, int b) {
    return (a * b) / gcd(a, b);
}

int main() {
    int n, m;
    
    // Input
    printf("Enter the value of n: ");
    scanf("%d", &n);
    printf("Enter the value of m: ");
    scanf("%d", &m);
    
    // Calculating gcd and lcm
    int gcd_result = gcd(n, m);
    int lcm_result = lcm(n, m);
    
    // Output
    printf("%d ; %d\n", gcd_result, lcm_result);
    
    return 0;
}


