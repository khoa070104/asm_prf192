#include <stdio.h>
#include <math.h>

// Function to check if a number is prime
int isPrime(int n) {
    if (n <= 1) {
        return 0;
    }
    int i = 2;
    for (; i <= sqrt(n); i++) {
        if (n % i == 0) {
            return 0;
        }
    }
    return 1;
}

int main() {
    int n;

    // Input value for n
    printf("Enter the value of n: ");
    scanf("%d", &n);

    // Check if n is prime
    if (isPrime(n)) {
        // If n is prime, print square of n
        printf("%d^2 = %d\n", n, n * n);
    } else {
        // If n is not prime, print n * 2
        printf("%d * 2 = %d\n", n, n * 2);
    }

    return 0;
}

